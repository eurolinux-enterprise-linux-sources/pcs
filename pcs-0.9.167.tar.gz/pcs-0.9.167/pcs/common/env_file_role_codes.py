from __future__ import (
    absolute_import,
    division,
    print_function,
)

BOOTH_CONFIG = "BOOTH_CONFIG"
BOOTH_KEY = "BOOTH_KEY"
PACEMAKER_AUTHKEY = "PACEMAKER_AUTHKEY"
