from __future__ import (
    absolute_import,
    division,
    print_function,
)

TARGET_TYPE_NODE = "node"
TARGET_TYPE_REGEXP = "regexp"
TARGET_TYPE_ATTRIBUTE = "attribute"
