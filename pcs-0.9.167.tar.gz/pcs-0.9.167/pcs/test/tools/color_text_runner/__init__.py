from __future__ import (
    absolute_import,
    division,
    print_function,
)

from pcs.test.tools.color_text_runner.result import get_text_test_result_class
